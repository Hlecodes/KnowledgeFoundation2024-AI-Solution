<div class="items-center text-center bg-slate-300 font-semibold text-l">
    Couldn't find requested resource  ¯\_(ツ)_/¯ 
</div>
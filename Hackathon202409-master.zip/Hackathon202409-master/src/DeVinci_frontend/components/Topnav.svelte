<div class="devinci-topnav flex items-center justify-around flex-wrap p-3 text-l font-bold text-white">
  <a href='#top'>AI Assistant</a>
  <a href='/#/mychats'>My Chats</a>
  <a href='/#/about'>About</a>
</div>
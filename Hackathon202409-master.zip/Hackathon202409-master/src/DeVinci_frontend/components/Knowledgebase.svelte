<div class="z-50 w-full relative">
    <form class="w-full mx-auto flex flex-row flex-grow">
        <label for="pdf_input">
            <button type="button" class="inline-flex justify-center p-2 mr-1 text-gray-500 rounded-lg cursor-pointer hover:text-gray-900 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-white dark:hover:bg-gray-600">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#5f6368"><path d="M720-330q0 104-73 177T470-80q-104 0-177-73t-73-177v-370q0-75 52.5-127.5T400-880q75 0 127.5 52.5T580-700v350q0 46-32 78t-78 32q-46 0-78-32t-32-78v-370h80v370q0 13 8.5 21.5T470-320q13 0 21.5-8.5T500-350v-350q-1-42-29.5-71T400-800q-42 0-71 29t-29 71v370q-1 71 49 120.5T470-160q70 0 119-49.5T640-330v-390h80v390Z"/></svg>
            </button>
        </label>
        <input class="hidden text-sm text-gray-900 border border-gray-300 cursor-pointer bg-gray-50 ml-2" id="pdf_input" type="file">
        <select id="knowledge" class="bg-gray-50 w-full rounded-full border-gray-300 text-gray-900 text-sm focus:ring-gray-500 border-4 focus:border-gray-500 block p-2.5">
            <option selected>Select PDF</option>
            <option value="a">pdf a</option>
            <option value="b">pdf a</option>
            <option value="c">pdf a</option>
            <option value="d">pdf a</option>
        </select>
    </form>
</div>
